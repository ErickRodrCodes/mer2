## 0.1.3-DEV.0 (2025-06-23)

### 🩹 Fixes

- on CI mode, the dist folder doesn't exist, deletion is unnecesary ([e8239fb](https://github.com/ErickRodrCodes/nx-plugins/commit/e8239fb))

### ❤️ Thank You

- Erick Rodriguez

## 0.1.2 (2025-04-02)

This was a version bump only for nx-electron-vite to align it with other projects, there were no code changes.

## 0.1.1 (2025-03-31)

This was a version bump only for nx-electron-vite to align it with other projects, there were no code changes.

## 0.1.0 (2025-03-20)

### 🚀 Features

- Added support for optional pathTarget in the schema to specify a custom path for .node binaries builds ([9bbd10d](https://github.com/ErickRodrCodes/nx-plugins/commit/9bbd10d))

### ❤️ Thank You

- Erick Rodriguez

# 0.0.0 (2025-03-16)

### 🩹 Fixes

- ensure all paths use forward slashes in project.json generation ([fcc030f](https://github.com/ErickRodrCodes/nx-plugins/commit/fcc030f))
- improve nameProject handling in normalizeOptions ([f504b5d](https://github.com/ErickRodrCodes/nx-plugins/commit/f504b5d))
- restore ^build dependency in nx-release-publish ([082baf4](https://github.com/ErickRodrCodes/nx-plugins/commit/082baf4))
- remove package.json from build assets to prevent version override ([31cd3c2](https://github.com/ErickRodrCodes/nx-plugins/commit/31cd3c2))

### ❤️ Thank You

- Erick Rodriguez

## 0.0.4 (2025-03-15)

This was a version bump only for nx-electron-vite to align it with other projects, there were no code changes.

## 0.0.3 (2025-03-15)

This was a version bump only for nx-electron-vite to align it with other projects, there were no code changes.

## 0.0.2 (2025-03-15)

This was a version bump only for nx-electron-vite to align it with other projects, there were no code changes.

## 0.0.1 (2025-03-15)

This was a version bump only for nx-electron-vite to align it with other projects, there were no code changes.
