import { ExecutorContext } from '@nx/devkit';
import { BuildElectronExecutorSchema } from './schema';
export default function electronBuildExecutor(options: BuildElectronExecutorSchema, context: ExecutorContext): Promise<{
    success: boolean;
}>;
