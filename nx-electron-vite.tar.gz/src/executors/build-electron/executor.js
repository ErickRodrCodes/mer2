"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = electronBuildExecutor;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const node_fs_1 = require("node:fs");
const promises_1 = require("node:fs/promises");
const path = require("node:path/posix");
const node_path_1 = require("node:path");
const utils_1 = require("../../util/utils");
function electronBuildExecutor(options, context) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const { hostProject, hostProjectRoot, mainOutputFilename, mainOutputPath, author, description, } = options;
        devkit_1.logger.warn(`
===============================
⚠️ ⚠️ ⚠️  Important ⚠️ ⚠️ ⚠️

NEVER run this executor in parallel with other nx-electron-vite builders or a custom electron build.
It will write the package.json of the workspace to define the main js target file for your project.
Our advice is to run multiple nx-electron-vite projects in sequence to prevent undesired side effects.

The dist folder will be cleaned while running this executor.
===============================
  `);
        const workspace = devkit_1.workspaceRoot;
        const packageJson = (0, node_fs_1.readFileSync)(path.join(workspace, 'package.json'), 'utf-8');
        const originalPackageJson = JSON.parse(packageJson);
        const parsedPackageJson = JSON.parse(packageJson);
        parsedPackageJson.main = path.join(mainOutputPath, mainOutputFilename);
        parsedPackageJson.author = author;
        parsedPackageJson.description = description;
        // TODO: add author and description to package.json
        devkit_1.logger.warn(`🧪 Updating package.json to be used on the build process.`);
        yield (0, promises_1.writeFile)(path.join(workspace, 'package.json'), JSON.stringify(parsedPackageJson, null, 2));
        devkit_1.logger.warn(`
🧪 Building Electron App with electron-builder from built files from ${hostProject}...
`);
        const resolveConfigFile = (0, node_path_1.join)(hostProjectRoot, 'src', 'electron-builder.yml');
        const commandLine = `${(0, devkit_1.getPackageManagerCommand)().exec} electron-builder --config=${resolveConfigFile}`;
        try {
            yield (0, utils_1.runCommandUntil)(commandLine, (criteria) => criteria.includes('building block map'));
        }
        catch (error) {
            devkit_1.logger.error('Electron build failed.');
            yield (0, utils_1.restorePackageJson)(workspace, originalPackageJson);
            return { success: false };
        }
        devkit_1.logger.warn(`
✅ Electron build completed. Restoring package.json...`);
        yield (0, utils_1.restorePackageJson)(workspace, originalPackageJson);
        return {
            success: true,
        };
    });
}
//# sourceMappingURL=executor.js.map