import { BuildIconsExecutorSchema } from './schema';
export declare const generateAppIcon: (options: BuildIconsExecutorSchema) => Promise<{
    success: boolean;
    message: string;
} | {
    success: boolean;
    message?: undefined;
}>;
export declare const generateAppSetup: (options: BuildIconsExecutorSchema) => Promise<{
    success: boolean;
    message: string;
} | {
    success: boolean;
    message?: undefined;
}>;
export default function runExecutor(options: BuildIconsExecutorSchema): Promise<{
    success: boolean;
    message: string;
} | {
    success: boolean;
    message?: undefined;
}>;
