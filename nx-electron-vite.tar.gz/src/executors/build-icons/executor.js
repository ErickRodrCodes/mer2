"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateAppSetup = exports.generateAppIcon = void 0;
exports.default = runExecutor;
const tslib_1 = require("tslib");
const utils_1 = require("../../util/utils");
const generateAppIcon = (options) => tslib_1.__awaiter(void 0, void 0, void 0, function* () { return runIconGenerator(options, 'icon'); });
exports.generateAppIcon = generateAppIcon;
const generateAppSetup = (options) => tslib_1.__awaiter(void 0, void 0, void 0, function* () { return runIconGenerator(options, 'setup'); });
exports.generateAppSetup = generateAppSetup;
function runIconGenerator(options, type) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const successString = 'png2icons done';
        const { hostProject, hostProjectRoot, iconOutputPath } = options;
        const generalParams = {
            hostProject,
            hostProjectRoot,
            osPlatform: process.platform,
            iconOutputPath,
        };
        const paramIcon = Object.assign(Object.assign({}, generalParams), { type });
        const appCommand = yield (0, utils_1.resolveIconCommand)(paramIcon);
        const response = yield (0, utils_1.runCommandUntil)(appCommand, (criteria) => criteria.includes(successString));
        if (!response) {
            return {
                success: false,
                message: `Error while generating icons for ${type}`,
            };
        }
        return {
            success: true,
        };
    });
}
// The main executor function for nx
function runExecutor(options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        // Dispatch based on the provided mode:
        switch (options.mode) {
            case 'app': {
                return yield (0, exports.generateAppIcon)(options);
            }
            case 'setup': {
                return yield (0, exports.generateAppSetup)(options);
            }
            case 'composite': {
                // Run the app icon generation first.
                const appResult = yield (0, exports.generateAppIcon)(options);
                if (!appResult.success) {
                    return appResult;
                }
                // Then run the setup icon generation.
                const setupResult = yield (0, exports.generateAppSetup)(options);
                if (!setupResult.success) {
                    return setupResult;
                }
                return { success: true };
            }
            default: {
                return {
                    success: false,
                    message: 'Invalid mode provided. Valid values are "app", "setup", or "composite".',
                };
            }
        }
    });
}
//# sourceMappingURL=executor.js.map