import { GeneratorCallback, Tree } from '@nx/devkit';
import { buldNativeSchema } from './schema';
export declare function _buildNativeGenerator(tree: Tree, schema: buldNativeSchema): Promise<GeneratorCallback>;
export declare function buildNativeGenerator(tree: Tree, schema: buldNativeSchema): Promise<GeneratorCallback>;
export default buildNativeGenerator;
