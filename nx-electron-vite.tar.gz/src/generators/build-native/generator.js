"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports._buildNativeGenerator = _buildNativeGenerator;
exports.buildNativeGenerator = buildNativeGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const fs = require("fs");
const path = require("path");
const utils_1 = require("../../util/utils");
/**
 * Creates directory structure if it doesn't exist
 */
function ensureDirectoryExists(tree, targetPath) {
    if (!tree.exists(targetPath)) {
        const pathParts = targetPath.split('/');
        let currentPath = '';
        for (const part of pathParts) {
            currentPath = currentPath ? `${currentPath}/${part}` : part;
            if (!tree.exists(currentPath)) {
                tree.write(`${currentPath}/.keep`, '');
            }
        }
    }
}
/**
 * Copy a native module to the target path
 */
function copyNativeModule(tree, file, targetPath) {
    const extension = path.extname(file.nativeFilePath);
    const fileName = `${file.moduleName}${extension}`;
    const targetFilePath = `${targetPath}/${fileName}`;
    try {
        ensureDirectoryExists(tree, targetPath);
        const sourceContent = fs.readFileSync(file.nativeFilePath);
        tree.write(targetFilePath, sourceContent);
        devkit_1.logger.info(`📁 Copied ${fileName} to ${targetFilePath}`);
    }
    catch (e) {
        devkit_1.logger.error(`Unable to write the module ${fileName}: ${e.message}`);
    }
}
function _buildNativeGenerator(tree, schema) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const tasks = [];
        if (process.argv.includes('--dry-run')) {
            devkit_1.logger.warn('Note: The argument --dry-run is partially supported in this generator.\n- Electron rebuild will be executed to rebuild native node modules.\n- A log of files changed in the tree will be shown, but no changes will be made.\n');
        }
        // Validate npm package name
        if (!schema.npmPackageName || schema.npmPackageName.trim() === '') {
            throw new Error('No modules were provided to rebuild a node binary. Aborting');
        }
        // Determine target path
        let targetPath;
        if (schema.hostProject) {
            const getProject = (0, devkit_1.readProjectConfiguration)(tree, schema.hostProject);
            if (!getProject) {
                devkit_1.logger.error(`there is no app called ${schema.hostProject} in the structure of the monorepo. Aborting`);
                process.exit(1);
            }
            // Verify it's an electron-nx-vite project
            const children = tree.children(getProject.root);
            if (!children.includes('electron-nx-vite.config.ts')) {
                throw new Error('The selected project is not an @erickrodrcodes/nx-electron-vite host project. Aborting.');
            }
            if (!getProject.sourceRoot) {
                throw new Error(`The project ${schema.hostProject} does not have a sourceRoot defined. Aborting.`);
            }
            targetPath = `${getProject.sourceRoot}/main/native`;
        }
        else if (schema.pathTarget) {
            targetPath = schema.pathTarget;
        }
        else {
            throw new Error('You must provide either a hostProject or a pathTarget. Aborting.');
        }
        // Parse package names
        const packagesToBuild = schema.npmPackageName.includes(',')
            ? schema.npmPackageName.split(',').map(pkg => pkg.trim()).filter(Boolean)
            : [schema.npmPackageName];
        // Rebuild native modules
        const { successful, failed } = yield (0, utils_1.rebuildNativeModules)(packagesToBuild);
        // Log results
        if (successful.length > 0) {
            const successfulNames = successful.map(s => s.moduleName).join(', ');
            devkit_1.logger.info(`✅ Successfully rebuilt modules: ${successfulNames}`);
            // Copy modules to target location
            successful.forEach(file => copyNativeModule(tree, file, targetPath));
        }
        if (failed.length > 0) {
            const failedNames = failed.map(f => f.moduleName).join(', ');
            devkit_1.logger.error(`❌ Failed to rebuild modules: ${failedNames}`);
        }
        return (0, devkit_1.runTasksInSerial)(...tasks);
    });
}
function buildNativeGenerator(tree, schema) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const installTask = yield _buildNativeGenerator(tree, schema);
        yield (0, devkit_1.formatFiles)(tree);
        return installTask;
    });
}
exports.default = buildNativeGenerator;
//# sourceMappingURL=generator.js.map