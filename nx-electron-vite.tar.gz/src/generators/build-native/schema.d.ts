export interface buldNativeSchema {
  hostProject?: string;
  npmPackageName: string;
  pathTarget?: string;
}
