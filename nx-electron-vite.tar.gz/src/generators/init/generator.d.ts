import { GeneratorCallback, Tree } from '@nx/devkit';
import { initSchema } from './schema';
export declare function initGenerator(tree: Tree, schema: initSchema): Promise<GeneratorCallback>;
export default initGenerator;
