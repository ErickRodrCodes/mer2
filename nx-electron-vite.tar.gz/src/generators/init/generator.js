"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initGenerator = initGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const vite_1 = require("@nx/vite");
const versions_1 = require("../../util/versions");
function ensureVitePlugin(tree) {
    const nxJson = (0, devkit_1.readJson)(tree, 'nx.json');
    // Initialize plugins array if it doesn't exist
    if (!nxJson.plugins) {
        nxJson.plugins = [];
    }
    // Check if Vite plugin already exists
    const vitePluginExists = nxJson.plugins.some((plugin) => plugin.plugin === '@nx/vite/plugin');
    // Add Vite plugin if it doesn't exist
    if (!vitePluginExists) {
        nxJson.plugins.push({
            plugin: '@nx/vite/plugin',
            options: {
                buildTargetName: 'build',
                testTargetName: 'test',
                serveTargetName: 'serve',
                previewTargetName: 'preview',
                serveStaticTargetName: 'serve-static',
            },
        });
        (0, devkit_1.writeJson)(tree, 'nx.json', nxJson);
    }
}
function initGenerator(tree, schema) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const tasks = [];
        // Initialize Vite first
        const viteInitTask = yield (0, vite_1.initGenerator)(tree, { skipFormat: true });
        tasks.push(viteInitTask);
        // Ensure Vite plugin is configured
        ensureVitePlugin(tree);
        if (!schema.skipPackageJson) {
            // Remove existing dependencies to ensure clean state
            tasks.push((0, devkit_1.removeDependenciesFromPackageJson)(tree, [], versions_1.devDependencies));
            // Add all required dependencies
            tasks.push((0, devkit_1.addDependenciesToPackageJson)(tree, {}, // No runtime dependencies
            {
                '@nx/vite': devkit_1.NX_VERSION,
                'electron-builder': versions_1.versionLibraries.electronBuilder,
                '@electron/rebuild': versions_1.versionLibraries.electronRebuild,
                electron: versions_1.versionLibraries.electron,
                'vite-plugin-electron-renderer': versions_1.versionLibraries.vitePluginElectronRenderer,
                'vite-plugin-electron': versions_1.versionLibraries.vitePluginElectron,
                png2icons: versions_1.versionLibraries.png2icons,
                'wait-on': versions_1.versionLibraries.waitOn,
                vitest: versions_1.versionLibraries.vitest,
                'electron-is-dev': versions_1.versionLibraries.electronIsDev,
                'electron-log': versions_1.versionLibraries.electronLog,
            }));
            tasks.push(() => {
                (0, devkit_1.installPackagesTask)(tree, true);
            });
        }
        if (!schema.skipFormat) {
            yield (0, devkit_1.formatFiles)(tree);
        }
        return (0, devkit_1.runTasksInSerial)(...tasks);
    });
}
exports.default = initGenerator;
//# sourceMappingURL=generator.js.map