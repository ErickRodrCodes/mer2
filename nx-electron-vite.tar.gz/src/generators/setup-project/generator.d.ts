import { GeneratorCallback, Tree } from '@nx/devkit';
import { SetupProjectSchema } from './schema';
export declare function updateDependencies(tree: Tree, schema: SetupProjectSchema): Promise<GeneratorCallback>;
export declare function setupProjectGenerator(tree: Tree, schema: SetupProjectSchema): Promise<GeneratorCallback>;
export default setupProjectGenerator;
