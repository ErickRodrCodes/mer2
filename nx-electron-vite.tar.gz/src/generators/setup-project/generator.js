"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateDependencies = updateDependencies;
exports.setupProjectGenerator = setupProjectGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const path_1 = require("path");
const utils_1 = require("../../util/utils");
function updateDependencies(tree, schema) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const tasks = [];
        if (!schema.guestProject) {
            throw new Error('Guest project is required');
        }
        const options = yield (0, utils_1.normalizeOptions)(tree, schema);
        if (!(yield (0, utils_1.isApplication)(tree, options.guestProject))) {
            throw new Error('The selected project is not an application. Aborting.');
        }
        // Cleanup and install dependencies
        const cleanupTask = yield (0, utils_1.cleanupDependencies)(tree, options);
        tasks.push(cleanupTask);
        const installTask = yield (0, utils_1.installDependencies)(tree, options);
        tasks.push(installTask);
        // Generate project files using the normalized project root
        (0, devkit_1.generateFiles)(tree, (0, path_1.join)(__dirname, 'files'), options.directory, Object.assign({}, options));
        // Add project configuration
        (0, devkit_1.addProjectConfiguration)(tree, options.nameProject, {
            name: options.nameProject,
            projectType: 'application',
            root: options.directory,
            sourceRoot: options.directoryRoot,
            implicitDependencies: [options.guestProject],
            targets: {
                build: {
                    executor: '@nx/vite:build',
                    dependsOn: [
                        {
                            projects: [options.guestProject],
                            target: 'build',
                        },
                    ],
                    options: {
                        outputPath: options.outputDistFolder,
                    },
                },
                serve: {
                    executor: '@nx/vite:dev-server',
                    options: {
                        buildTarget: `${options.nameProject}:build`,
                    },
                    configurations: {
                        electron: {
                            dependsOn: ['build'],
                            commands: [
                                `nx run ${options.guestProject}:serve`,
                                `nx run ${options.nameProject}:serve`,
                            ],
                            parallel: true,
                        },
                    },
                },
                electron: {
                    configurations: {
                        build: {
                            dependsOn: [
                                {
                                    projects: [options.nameProject],
                                    target: 'build',
                                },
                            ],
                            options: {
                                commands: [`nx run ${options.nameProject}:build`],
                                parallel: false,
                            },
                        },
                        serve: {
                            dependsOn: ['build'],
                            commands: [
                                `nx run ${options.guestProject}:serve`,
                                `nx run ${options.nameProject}:serve`,
                            ],
                            parallel: true,
                        },
                    },
                    executor: 'nx:run-commands',
                    defaultConfiguration: 'serve',
                },
                'nx-electron-icons': {
                    executor: '@erickrodrcodes/nx-electron-vite:build-icon',
                    defaultConfiguration: 'default',
                    dependsOn: [
                        {
                            projects: [options.nameProject],
                            target: 'build',
                        },
                    ],
                    options: {
                        hostProject: options.nameProject,
                        hostProjectRoot: '{projectRoot}',
                        iconOutputPath: options.outputDistFolderIcons,
                        mode: 'composite',
                    },
                    configurations: {
                        app: {
                            mode: 'app',
                        },
                        setup: {
                            mode: 'setup',
                        },
                        default: {
                            mode: 'composite',
                        },
                    },
                },
                dist: {
                    dependsOn: [
                        {
                            projects: [options.nameProject],
                            target: 'nx-electron-icons',
                        },
                    ],
                    executor: '@erickrodrcodes/nx-electron-vite:build-electron',
                    options: {
                        hostProject: options.nameProject,
                        guestProject: options.guestProject,
                        hostProjectRoot: '{projectRoot}',
                        mainOutputPath: options.outputDistFolder,
                        mainOutputFilename: 'main.js',
                        author: options.author,
                        description: options.description,
                    },
                },
                preview: {
                    executor: '@nx/vite:preview-server',
                    options: {
                        buildTarget: `${options.nameProject}:build`,
                    },
                },
                test: {
                    executor: '@nx/vite:test',
                    options: {
                        config: '{projectRoot}/vite.config.ts',
                    },
                },
                lint: {
                    dependsOn: ['^lint'],
                },
            },
        });
        return (0, devkit_1.runTasksInSerial)(...tasks);
    });
}
function setupProjectGenerator(tree, schema) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const installTask = yield updateDependencies(tree, schema);
        yield (0, devkit_1.formatFiles)(tree);
        return installTask;
    });
}
exports.default = setupProjectGenerator;
//# sourceMappingURL=generator.js.map