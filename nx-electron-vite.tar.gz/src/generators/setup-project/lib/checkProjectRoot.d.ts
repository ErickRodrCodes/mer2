import { ProjectConfiguration } from '@nx/devkit';
/**
 * Checks if the root project meets required criteria.
 *
 * @param rootProject - The project to validate.
 * @param options - Contains `hostProject` to specify the project name.
 * @throws Error if project not found or not an application.
 */
export declare const checkRootProject: (rootProject: ProjectConfiguration, options: any) => void;
