import { Tree } from '@nx/devkit';
export declare function injectViteConfig(pathToConfig: string, tree: Tree): string;
