import { GeneratorCallback, Tree } from '@nx/devkit';
import { ChildProcess } from 'child_process';
import { platform } from 'process';
import { SetupProjectSchema } from '../generators/setup-project/schema';
/**
 * Represents the operating system platform.
 */
export declare const osPlatform: typeof process.platform;
/**
 * Represents command parameters for icon resolution.
 */
export interface CommandParams {
    hostProjectRoot: string;
    hostProject: string;
    osPlatform: typeof platform;
    iconOutputPath: string;
}
/**
 * Represents command parameters for resolving icon commands.
 */
export interface ResolveIconCommandParams extends CommandParams {
    type: 'icon' | 'setup';
}
/**
 * Represents the result of rebuilding native modules.
 */
export interface RebuildResult {
    successful: Array<{
        moduleName: string;
        nativeFilePath: string;
    }>;
    failed: Array<{
        moduleName: string;
        error: string;
    }>;
}
/**
 * Retrieves the output directory for a specified project.
 * @param {Tree} tree - Represents the file system.
 * @param {string} projectName - The name of the project.
 * @returns {Promise<string>} - The output directory path for the project.
 */
export declare function getProjectOutputDirectory(tree: Tree, projectName: string): Promise<string>;
/**
 * Retrieves the output path from the Vite configuration for a specified project.
 * @param {Tree} tree - Represents the file system.
 * @param {string} projectName - The name of the project.
 * @returns {Promise<string>} - The output path specified in the Vite configuration.
 * @throws {Error} If the Vite configuration file cannot be read.
 */
export declare function getViteOutputPath(tree: Tree, projectName: string): Promise<string>;
/**
 * Normalizes options for setting up a project.
 * @param {Tree} tree - Represents the file system.
 * @param {SetupProjectSchema} schema - The schema containing project setup options.
 * @returns {Promise<SetupProjectSchema>} - The normalized project options.
 */
export declare function normalizeOptions(tree: Tree, schema: SetupProjectSchema): Promise<SetupProjectSchema>;
/**
 * Checks if a project is an application.
 * @param {Tree} tree - Represents the file system.
 * @param {string} guestProject - The name of the guest project.
 * @returns {Promise<boolean>} - True if the project is an application, otherwise false.
 */
export declare const isApplication: (tree: Tree, guestProject: string) => Promise<boolean>;
/**
 * Retrieves the root TypeScript configuration file path.
 * @returns {string|null} - The path to the root TypeScript configuration file or null if not found.
 */
export declare function getRootTsConfigPath(): string | null;
/**
 * Checks if the current Node.js version meets the suggested version.
 * If the current version is lower than the suggested version, an error is thrown.
 * @param {string} currentVersion - The current Node.js version.
 * @param {string} suggestedNodeVersion - The suggested Node.js version.
 * @throws {Error} If the current Node.js version is lower than the suggested version.
 */
export declare const checkNodeVersion: (currentVersion: string, suggestedNodeVersion: string) => void;
/**
 * Cleans up dependencies from the package.json file.
 * @param {Tree} tree - Represents the file system.
 * @param {SetupProjectSchema} schema - The schema containing project setup options.
 * @returns {Promise<void>} - A promise that resolves when the cleanup is complete.
 */
export declare const cleanupDependencies: (tree: Tree, schema: SetupProjectSchema) => Promise<GeneratorCallback>;
/**
 * Installs dependencies for the project.
 * @param {Tree} tree - Represents the file system.
 * @param {SetupProjectSchema} schema - The schema containing project setup options.
 * @returns {Promise<GeneratorCallback>} - A promise that resolves with a callback for the generator.
 */
export declare const installDependencies: (tree: Tree, schema: SetupProjectSchema) => Promise<GeneratorCallback>;
/**
 * Compares two Node.js versions to determine if one is greater than the other.
 * @param {string} version1 - The first version to compare.
 * @param {string} version2 - The second version to compare.
 * @returns {number} - Returns 1 if version1 is greater, -1 if version2 is greater, or 0 if they are equal.
 */
export declare function compareNodeVersion(version1: string, version2: string): number;
/**
 * Runs a command until a specified criteria is met.
 * @param {string} command - The command to run.
 * @param {(output: string) => boolean} criteria - The criteria to meet as a text output. If the criteria is met, the promise resolves.
 * @returns {Promise<ChildProcess>} - A promise that resolves when the criteria is met.
 */
export declare function runCommandUntil(command: string, criteria: (output: string) => boolean): Promise<ChildProcess>;
/**
 * Restores the package.json file to its original state.
 * @param {string} workspace - The path to the workspace.
 * @param {object} originalPackageJson - The original package.json object.
 * @returns {Promise<void>} - A promise that resolves when the restoration is complete.
 */
export declare function restorePackageJson(workspace: string, originalPackageJson: object): Promise<void>;
/**
 * Deletes a directory and its contents.
 * @param {string} directoryPath - The path to the directory to delete.
 * @returns {Promise<void>} - A promise that resolves when the directory is deleted.
 * @throws {Error} If there is an error deleting the directory.
 */
export declare function deleteDirectory(directoryPath: string): Promise<void>;
/**
 * Represents the result of rebuilding native modules.
 */
export interface RebuildResult {
    successful: Array<{
        moduleName: string;
        nativeFilePath: string;
    }>;
    failed: Array<{
        moduleName: string;
        error: string;
    }>;
}
/**
 * Resolves the icon command parameters and ensures the output directory exists.
 * @param {ResolveIconCommandParams} params - The parameters for resolving the icon command.
 * @returns {Promise<string>} - The command to execute for icon generation.
 */
export declare function resolveIconCommand(params: ResolveIconCommandParams): Promise<string>;
/**
 * Rebuilds one or more native modules for Electron.
 * @param {string|string[]} moduleNames - Single module name or array of module names.
 * @returns {Promise<RebuildResult>} - An object containing arrays of successful and failed rebuilds.
 * @throws {Error} If any module is invalid or if the rebuild process fails.
 */
export declare function rebuildNativeModules(moduleNames: string | string[]): Promise<RebuildResult>;
