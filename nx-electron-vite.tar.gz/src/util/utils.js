"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.installDependencies = exports.cleanupDependencies = exports.checkNodeVersion = exports.isApplication = exports.osPlatform = void 0;
exports.getProjectOutputDirectory = getProjectOutputDirectory;
exports.getViteOutputPath = getViteOutputPath;
exports.normalizeOptions = normalizeOptions;
exports.getRootTsConfigPath = getRootTsConfigPath;
exports.compareNodeVersion = compareNodeVersion;
exports.runCommandUntil = runCommandUntil;
exports.restorePackageJson = restorePackageJson;
exports.deleteDirectory = deleteDirectory;
exports.resolveIconCommand = resolveIconCommand;
exports.rebuildNativeModules = rebuildNativeModules;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const rebuild_1 = require("@electron/rebuild");
const project_name_and_root_utils_1 = require("@nx/devkit/src/generators/project-name-and-root-utils");
const child_process_1 = require("child_process");
const fs_1 = require("fs");
const promises_1 = require("fs/promises");
const promises_2 = require("node:fs/promises");
const path = require("path");
const path_1 = require("path");
const process_1 = require("process");
const versions_1 = require("./versions");
/**
 * Represents the operating system platform.
 */
exports.osPlatform = process.platform;
/**
 * Retrieves the output directory for a specified project.
 * @param {Tree} tree - Represents the file system.
 * @param {string} projectName - The name of the project.
 * @returns {Promise<string>} - The output directory path for the project.
 */
function getProjectOutputDirectory(tree, projectName) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        const options = (0, devkit_1.readProjectConfiguration)(tree, projectName);
        if ((_c = (_b = (_a = options.targets) === null || _a === void 0 ? void 0 : _a.build) === null || _b === void 0 ? void 0 : _b.options) === null || _c === void 0 ? void 0 : _c.outputPath) {
            return options.targets.build.options.outputPath.replace(/\.\.\//g, '');
        }
        else {
            const viteOutputPath = yield getViteOutputPath(tree, projectName);
            if (viteOutputPath !== '') {
                return viteOutputPath;
            }
            devkit_1.logger.warn(`Could not find the output path for project ${projectName}. The value 'OUTPUT_DIST_GUEST_PROJECT' will be used for you to change manually on the generated files.`);
            return 'OUTPUT_DIST_GUEST_PROJECT';
        }
    });
}
/**
 * Retrieves the output path from the Vite configuration for a specified project.
 * @param {Tree} tree - Represents the file system.
 * @param {string} projectName - The name of the project.
 * @returns {Promise<string>} - The output path specified in the Vite configuration.
 * @throws {Error} If the Vite configuration file cannot be read.
 */
function getViteOutputPath(tree, projectName) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const projectConfig = (0, devkit_1.readProjectConfiguration)(tree, projectName);
        const viteConfigPath = path.posix.join(projectConfig.root, 'vite.config.ts');
        if (!tree.exists(viteConfigPath)) {
            return '';
        }
        const viteConfigContent = tree.read(viteConfigPath, 'utf-8');
        if (!viteConfigContent) {
            throw new Error(`Unable to read Vite configuration file: ${viteConfigPath}`);
        }
        const viteConfig = yield Promise.resolve(`${path.resolve(viteConfigPath)}`).then(s => require(s));
        // Dynamically import the Vite config file
        if ((_b = (_a = viteConfig === null || viteConfig === void 0 ? void 0 : viteConfig.default) === null || _a === void 0 ? void 0 : _a.build) === null || _b === void 0 ? void 0 : _b.outDir) {
            const outputPath = viteConfig.default.build.outDir;
            return outputPath.replace(/\.\.\//g, '');
        }
        return '';
    });
}
/**
 * Normalizes options for setting up a project.
 * @param {Tree} tree - Represents the file system.
 * @param {SetupProjectSchema} schema - The schema containing project setup options.
 * @returns {Promise<SetupProjectSchema>} - The normalized project options.
 */
function normalizeOptions(tree, schema) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        // Normalize project name: use guestProject-electron only if nameProject is undefined, null, empty string or whitespace
        const projectName = schema.nameProject === undefined ||
            schema.nameProject === null ||
            schema.nameProject.trim() === ''
            ? `${schema.guestProject}-electron`
            : schema.nameProject;
        // Get the workspace layout to determine where applications should go
        const workspaceLayout = (0, devkit_1.getWorkspaceLayout)(tree);
        // If directory is undefined, empty, or just whitespace, use the workspace default
        const directory = !schema.directory || schema.directory.trim() === ''
            ? workspaceLayout.appsDir
            : schema.directory.trim();
        // Let Nx determine the final project name and root directory
        const newProject = yield (0, project_name_and_root_utils_1.determineProjectNameAndRootOptions)(tree, {
            name: projectName,
            projectType: 'application',
            directory: directory,
        });
        // Ensure the directory path is correctly constructed
        const projectDirectory = path.posix.join(directory, projectName);
        const outputGuestDirectory = yield getProjectOutputDirectory(tree, schema.guestProject);
        const options = {
            directory: projectDirectory,
            directoryRoot: path.posix.join(projectDirectory, 'src'),
            guestProject: schema.guestProject,
            nameProject: newProject.projectName,
            name: schema.name,
            author: schema.author,
            description: schema.description,
            executableName: schema.executableName,
            updater: schema.updater,
            testRunner: schema.testRunner,
            guestDistFolder: outputGuestDirectory,
            outputDistFolderIcons: `dist/${projectDirectory}-icons`,
            outputDistFolder: `dist/${projectDirectory}`,
            directoryResources: path.posix.join(projectDirectory, 'src/resources'),
            offsetFromRoot: (0, devkit_1.offsetFromRoot)(projectDirectory),
            rootTsConfigPath: `${(0, devkit_1.offsetFromRoot)(projectDirectory)}${getRootTsConfigPath()}`,
            nsisExtraFilePath: path.posix.join(projectDirectory, 'src/installer.nsh'),
        };
        return options;
    });
}
/**
 * Checks if a project is an application.
 * @param {Tree} tree - Represents the file system.
 * @param {string} guestProject - The name of the guest project.
 * @returns {Promise<boolean>} - True if the project is an application, otherwise false.
 */
const isApplication = (tree, guestProject) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const project = (0, devkit_1.readProjectConfiguration)(tree, guestProject);
    return project.projectType === 'application';
});
exports.isApplication = isApplication;
/**
 * Retrieves the root TypeScript configuration file path.
 * @returns {string|null} - The path to the root TypeScript configuration file or null if not found.
 */
function getRootTsConfigPath() {
    const tsConfigFileName = getRootTsConfigFileName();
    return tsConfigFileName || null;
}
/**
 * Gets the name of the root TypeScript configuration file.
 * @returns {string|null} - The name of the TypeScript configuration file or null if not found.
 */
function getRootTsConfigFileName() {
    for (const tsConfigName of ['tsconfig.base.json', 'tsconfig.json']) {
        const tsConfigPath = path.posix.join(devkit_1.workspaceRoot, tsConfigName);
        if ((0, fs_1.existsSync)(tsConfigPath)) {
            return tsConfigName;
        }
    }
    return null;
}
/**
 * Checks if the current Node.js version meets the suggested version.
 * If the current version is lower than the suggested version, an error is thrown.
 * @param {string} currentVersion - The current Node.js version.
 * @param {string} suggestedNodeVersion - The suggested Node.js version.
 * @throws {Error} If the current Node.js version is lower than the suggested version.
 */
const checkNodeVersion = (currentVersion, suggestedNodeVersion) => {
    if (compareNodeVersion(currentVersion, suggestedNodeVersion) === -1) {
        throw new Error(`Your current node version ${currentVersion} is lower than the suggested version ${suggestedNodeVersion}. Please update your node version to ${suggestedNodeVersion} or higher.`);
    }
};
exports.checkNodeVersion = checkNodeVersion;
/**
 * Cleans up dependencies from the package.json file.
 * @param {Tree} tree - Represents the file system.
 * @param {SetupProjectSchema} schema - The schema containing project setup options.
 * @returns {Promise<void>} - A promise that resolves when the cleanup is complete.
 */
const cleanupDependencies = (tree, schema) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const devDependencies = [
        '@nx/web',
        'electron-builder',
        '@electron/rebuild',
        'electron',
        'vite-plugin-electron-renderer',
        'vite-plugin-electron',
        'png2icons',
    ];
    if (schema.testRunner && schema.testRunner === 'vitest') {
        devDependencies.push('vitest');
    }
    return (0, devkit_1.removeDependenciesFromPackageJson)(tree, [], devDependencies);
});
exports.cleanupDependencies = cleanupDependencies;
/**
 * Installs dependencies for the project.
 * @param {Tree} tree - Represents the file system.
 * @param {SetupProjectSchema} schema - The schema containing project setup options.
 * @returns {Promise<GeneratorCallback>} - A promise that resolves with a callback for the generator.
 */
const installDependencies = (tree, schema) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    // First check the current node version
    (0, exports.checkNodeVersion)(process.versions.node, versions_1.versionLibraries.node);
    const devDependencies = {
        '@nx/web': devkit_1.NX_VERSION,
        'electron-builder': versions_1.versionLibraries.electronBuilder,
        '@electron/rebuild': versions_1.versionLibraries.electronRebuild,
        electron: versions_1.versionLibraries.electron,
        'vite-plugin-electron-renderer': versions_1.versionLibraries.vitePluginElectronRenderer,
        'vite-plugin-electron': versions_1.versionLibraries.vitePluginElectron,
        png2icons: versions_1.versionLibraries.png2icons,
    };
    const dependencies = {};
    if (schema.testRunner && schema.testRunner === 'vitest') {
        devDependencies['vitest'] = versions_1.versionLibraries.vitest;
    }
    return yield (0, devkit_1.addDependenciesToPackageJson)(tree, dependencies, devDependencies);
});
exports.installDependencies = installDependencies;
/**
 * Compares two Node.js versions to determine if one is greater than the other.
 * @param {string} version1 - The first version to compare.
 * @param {string} version2 - The second version to compare.
 * @returns {number} - Returns 1 if version1 is greater, -1 if version2 is greater, or 0 if they are equal.
 */
function compareNodeVersion(version1, version2) {
    const v1 = version1.replace('v', '').split('.').map(Number);
    const v2 = version2.replace('v', '').split('.').map(Number);
    for (let i = 0; i < Math.max(v1.length, v2.length); i++) {
        const v1part = v1[i] || 0;
        const v2part = v2[i] || 0;
        if (v1part > v2part) {
            return 1; // version1 is greater
        }
        else if (v1part < v2part) {
            return -1; // version2 is greater
        }
    }
    return 0; // versions are equal
}
/**
 * Runs a command until a specified criteria is met.
 * @param {string} command - The command to run.
 * @param {(output: string) => boolean} criteria - The criteria to meet as a text output. If the criteria is met, the promise resolves.
 * @returns {Promise<ChildProcess>} - A promise that resolves when the criteria is met.
 */
function runCommandUntil(command, criteria) {
    const pathToWorkspace = (0, path_1.resolve)(devkit_1.workspaceRoot);
    const p = (0, child_process_1.exec)(`${command}`, {
        encoding: 'utf-8',
        cwd: pathToWorkspace,
    });
    return new Promise((res, rej) => {
        var _a, _b, _c, _d;
        let output = '';
        let complete = false;
        function checkCriteria(data) {
            output += data;
            if (criteria(output)) {
                complete = true;
                res(p);
            }
        }
        (_a = p.stdout) === null || _a === void 0 ? void 0 : _a.on('data', checkCriteria);
        (_b = p.stderr) === null || _b === void 0 ? void 0 : _b.on('data', checkCriteria);
        (_c = p.stdout) === null || _c === void 0 ? void 0 : _c.on('data', (data) => process.stdout.write(data));
        (_d = p.stderr) === null || _d === void 0 ? void 0 : _d.on('data', (data) => process.stderr.write(data));
        p.on('exit', (code) => {
            if (!complete) {
                rej(new Error(`Exited with ${code}`));
            }
            else {
                res(p);
            }
        });
        p.stderr.on('error', (error) => {
            devkit_1.logger.error(error);
            rej(error instanceof Error ? error : new Error(error));
        });
    });
}
/**
 * Restores the package.json file to its original state.
 * @param {string} workspace - The path to the workspace.
 * @param {object} originalPackageJson - The original package.json object.
 * @returns {Promise<void>} - A promise that resolves when the restoration is complete.
 */
function restorePackageJson(workspace, originalPackageJson) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        yield (0, promises_1.writeFile)(path.posix.join(workspace, 'package.json'), JSON.stringify(originalPackageJson, null, 2));
    });
}
/**
 * Deletes a directory and its contents.
 * @param {string} directoryPath - The path to the directory to delete.
 * @returns {Promise<void>} - A promise that resolves when the directory is deleted.
 * @throws {Error} If there is an error deleting the directory.
 */
function deleteDirectory(directoryPath) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        try {
            yield (0, promises_1.rm)(directoryPath, { recursive: true, force: true });
            devkit_1.logger.warn(`🗑️  Directory ${directoryPath} deleted successfully.`);
        }
        catch (error) {
            devkit_1.logger.error(`⚠️ Error deleting directory ${directoryPath}:`);
            devkit_1.logger.error(error);
            (0, process_1.exit)(1);
        }
    });
}
/**
 * Resolves the icon command parameters and ensures the output directory exists.
 * @param {ResolveIconCommandParams} params - The parameters for resolving the icon command.
 * @returns {Promise<string>} - The command to execute for icon generation.
 */
function resolveIconCommand(params) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        if (!(0, fs_1.existsSync)(params.iconOutputPath)) {
            yield (0, promises_1.mkdir)(params.iconOutputPath, { recursive: true });
        }
        const resolveSourceFile = path.posix.join(params.hostProjectRoot, 'src', 'resources', 'icon', 'source', `${params.type}.png`);
        const resolveTargetFile = path.posix.join(params.iconOutputPath, params.type);
        const _args = ` ${params.osPlatform === 'darwin' ? '-icns' : '-icop'} -hm -i`;
        return `${(0, devkit_1.getPackageManagerCommand)().exec} png2icons ${resolveSourceFile} ${resolveTargetFile} ${_args}`;
    });
}
/**
 * Validates if a module exists in node_modules.
 * @param {string} moduleName - The name of the module to check.
 * @returns {Promise<boolean>} - True if the module exists, otherwise false.
 */
function validateModule(moduleName) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        try {
            require.resolve(`${moduleName}/package.json`);
            return true;
        }
        catch (error) {
            devkit_1.logger.error(`❌ Module "${moduleName}" not found in node_modules`);
            return false;
        }
    });
}
/**
 * Rebuilds one or more native modules for Electron.
 * @param {string|string[]} moduleNames - Single module name or array of module names.
 * @returns {Promise<RebuildResult>} - An object containing arrays of successful and failed rebuilds.
 * @throws {Error} If any module is invalid or if the rebuild process fails.
 */
function rebuildNativeModules(moduleNames) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        // Ensure moduleNames is always an array
        const modules = Array.isArray(moduleNames) ? moduleNames : [moduleNames];
        if (modules.length === 0) {
            console.warn('⚠️ No modules specified for rebuilding');
            return { successful: [], failed: [] };
        }
        // Validate all modules first
        devkit_1.logger.info('🔍 Validating modules...');
        const validationResults = yield Promise.all(modules.map((moduleName) => tslib_1.__awaiter(this, void 0, void 0, function* () {
            return ({
                moduleName,
                exists: yield validateModule(moduleName),
            });
        })));
        // Filter out invalid modules
        const invalidModules = validationResults.filter((result) => !result.exists);
        const validModules = validationResults
            .filter((result) => result.exists)
            .map((result) => result.moduleName);
        // Early exit if any module is invalid
        if (invalidModules.length > 0) {
            const invalidModuleNames = invalidModules
                .map((m) => m.moduleName)
                .join(', ');
            throw new Error(`Cannot proceed with rebuild. Missing modules: ${invalidModuleNames}`);
        }
        // If we get here, all modules are valid
        devkit_1.logger.info('✅ All modules validated successfully');
        const successful = [];
        const failed = [];
        // Proceed with rebuilding all valid modules
        for (const moduleName of validModules) {
            try {
                devkit_1.logger.info(`📦 Rebuilding ${moduleName}...`);
                yield (0, rebuild_1.rebuild)({
                    buildPath: devkit_1.workspaceRoot,
                    force: true,
                    onlyModules: [moduleName],
                    electronVersion: versions_1.versionLibraries.electron.replace('^', ''),
                });
                const nativeFilePath = yield getNativeAddonFile(moduleName);
                successful.push({ moduleName, nativeFilePath });
                devkit_1.logger.info(`✅ Successfully rebuilt ${moduleName}`);
            }
            catch (error) {
                devkit_1.logger.error(`❌ Failed to rebuild ${moduleName}: ${error.message}`);
                failed.push({
                    moduleName,
                    error: error.message || 'Unknown error occurred during rebuild',
                });
            }
        }
        return { successful, failed };
    });
}
/**
 * Locates the native addon (.node) file for a given module.
 * @param {string} moduleName - Name of the module.
 * @returns {Promise<string>} - Path to the .node file.
 * @throws {Error} If the native addon file cannot be found.
 */
function getNativeAddonFile(moduleName) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        try {
            const modulePackagePath = require.resolve(`${moduleName}/package.json`);
            const moduleFolder = path.dirname(modulePackagePath);
            const nodeFile = yield findNodeFile(moduleFolder);
            if (!nodeFile) {
                throw new Error(`No .node file found for "${moduleName}" in ${moduleFolder}`);
            }
            return nodeFile;
        }
        catch (error) {
            throw new Error(`Failed to locate native addon for "${moduleName}": ${error.message}`);
        }
    });
}
/**
 * Recursively searches for a .node file in a directory.
 * @param {string} directory - Directory to search in.
 * @returns {Promise<string|null>} - Path to the .node file or null if not found.
 * @throws {Error} If there's an error accessing the directory.
 */
function findNodeFile(directory) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const entries = yield (0, promises_2.readdir)(directory, { withFileTypes: true });
        for (const entry of entries) {
            const fullPath = path.posix.join(directory, entry.name);
            if (entry.isFile() && path.extname(entry.name) === '.node') {
                return fullPath;
            }
            if (entry.isDirectory()) {
                const result = yield findNodeFile(fullPath);
                if (result)
                    return result;
            }
        }
        return null;
    });
}
//# sourceMappingURL=utils.js.map