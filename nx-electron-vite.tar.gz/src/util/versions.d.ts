export declare const versionLibraries: {
    electronBuilder: string;
    electronRebuild: string;
    electron: string;
    vitePluginElectronRenderer: string;
    vitePluginElectron: string;
    png2icons: string;
    suggestedNode: string;
    waitOn: string;
    node: string;
    vitest: string;
    electronIsDev: string;
    electronLog: string;
};
export declare const devDependencies: string[];
